package com.cg.banking.daoservices;

import com.cg.banking.beans.Customer;

public interface CustomerDao {
Customer save(Customer customer);
}
