package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.dto.Account;
import com.cg.service.*;

@Controller
public class BankingController {
	@Autowired
	BankingServices bankingSer=null;
	public BankingServices getBankingSer() {
		return bankingSer;
	}
	public void setBankingSer(BankingServices bankingSer) {
		this.bankingSer = bankingSer;
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login1(Model model) {
		Account account=new Account();
		model.addAttribute("account",account);
		return "Login";
	}
	@RequestMapping(value="/Success.obj",method=RequestMethod.POST)
	public String login1rgy(@ModelAttribute(value="account")Account account ,Model model) {
		if((account.getAccountNo()==1)&&(account.getPinNumber()==5282)) {
			model.addAttribute("message", "Logged in");
			model.addAttribute("account", account);
			return "Menu";}
		else {
		model.addAttribute("message","Wrong Credentials");
		return "Login";}
	}
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String register(Model model) {
		Account account=new Account();
		model.addAttribute("account",account);
		return "Register";
	}
	@RequestMapping(value="/insert.obj",method=RequestMethod.POST)
	public String reg(@ModelAttribute(value="account")Account account ,Model model) {
		bankingSer.openAccount(account);
		model.addAttribute("account", account);
		return "Register";
	}
	@RequestMapping(value="withdraw.obj",method=RequestMethod.POST)
	public String withdraw(Account account ,Model model) {
		model.addAttribute("widaccount", account);
		return "Withdraw";
	}
	
}
