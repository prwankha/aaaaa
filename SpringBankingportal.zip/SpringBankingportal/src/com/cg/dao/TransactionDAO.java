package com.cg.dao;

import java.util.List;
import com.cg.dto.Transaction;

public interface TransactionDAO {
	Transaction save(Transaction transaction);
	Transaction update(Transaction transaction);
	Transaction findOne(int transactionId);
	List<Transaction> findAll(long accountNo);
}
