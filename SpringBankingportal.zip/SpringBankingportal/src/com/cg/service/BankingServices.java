package com.cg.service;
import java.util.List;
import com.cg.dto.Account;
import com.cg.dto.Transaction;

public interface BankingServices {
	Account openAccount(Account account);

	Account depositAmount(long accountNo, float amount);

	Account withdrawAmount(long accountNo, float amount, int pinNumber);
	
	boolean findAccount(Account account);

	boolean fundTransfer(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber);

	Account getAccountDetails(Account account);

	List<Account> getAllAccountDetails();

	List<Transaction> getAccountAllTransaction(long accountNo);

	public String accountStatus(long accountNo);

}
