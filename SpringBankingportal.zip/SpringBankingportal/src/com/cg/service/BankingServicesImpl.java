package com.cg.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.dao.TransactionDAO;
import com.cg.dao.TransactionDAOImpl;
import com.cg.dto.Account;
import com.cg.dto.Transaction;
@Service(value="bankingSer")
public class BankingServicesImpl implements BankingServices {
@Autowired
AccountDAO accountDao=new AccountDAOImpl();
public AccountDAO getAccountDao() {
	return accountDao;
}
public void setAccountDao(AccountDAO accountDao) {
	this.accountDao = accountDao;
}
@Autowired
TransactionDAO transcationDao=new TransactionDAOImpl();
	public TransactionDAO getTranscationDao() {
	return transcationDao;
}
public void setTranscationDao(TransactionDAO transcationDao) {
	this.transcationDao = transcationDao;
}

@Override
	public Account openAccount(Account account) {
	account.setPinNumber((int) (Math.random()*9000+1500));
	account.setStatus("Active");
	accountDao.save(account);
	transcationDao.save(new Transaction(account.getAccountBalance(), "Initial Deposit", account));
	return account;
	}

	@Override
	public Account withdrawAmount(long accountNo, float amount, int pinNumber) {
		return null;
	}

	@Override
	public Account depositAmount(long accountNo, float amount){
		return null;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber) {
		return false;
	}

	@Override
	public Account getAccountDetails(Account account) {
		return null;
	}

	@Override
	public List<Account> getAllAccountDetails() {
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) {
		return null;
	}

	@Override
	public String accountStatus(long accountNo) {
		return null;
	}
	@Override
	public boolean findAccount(Account account) {
		if(accountDao.findOne(account.getAccountNo())!=null)
			return true;
		else
			return false;
	}

}
